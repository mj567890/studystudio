"""
apps/api/core/db.py
数据库连接与会话管理

C2（V2.6）：在 engine.connect 事件中注册 pgvector 编解码器，
           确保向量列返回 list[float] 而非 bytes。
"""
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from pgvector.asyncpg import register_vector
from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from apps.api.core.config import CONFIG


# ── 引擎创建 ──────────────────────────────────────────────────────────────
engine = create_async_engine(
    CONFIG.database.url,
    pool_pre_ping=True,
    pool_size=CONFIG.database.pool_size,
    max_overflow=CONFIG.database.max_overflow,
    echo=CONFIG.debug,
)


@event.listens_for(engine.sync_engine, "connect")
def on_connect(dbapi_conn, _connection_record) -> None:
    """
    C2：每个新连接注册 pgvector 类型编解码器。
    必须在此事件中注册，否则向量列查询返回原始 bytes 而非 list[float]。
    pgvector-python >= 0.3 提供 register_vector(conn)，
    在 sync 连接事件中通过 run_sync 调用。
    """
    dbapi_conn.run_sync(register_vector)


# ── 会话工厂 ──────────────────────────────────────────────────────────────
async_session_factory = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
)


class Base(DeclarativeBase):
    """所有 ORM 模型的基类"""
    pass


# ── 依赖注入用的会话获取函数 ─────────────────────────────────────────────
async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI Depends 使用，请求结束自动关闭 session。"""
    async with async_session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


@asynccontextmanager
async def get_independent_db() -> AsyncGenerator[AsyncSession, None]:
    """
    创建独立 session，不依赖任何请求生命周期。
    用于 BackgroundTasks、Celery 任务等场景。
    """
    async with async_session_factory() as session:
        async with session.begin():
            yield session


async def init_db() -> None:
    """应用启动时初始化数据库扩展。"""
    async with engine.begin() as conn:
        await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        await conn.execute(text("CREATE EXTENSION IF NOT EXISTS pg_trgm"))
