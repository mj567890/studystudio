"""
apps/api/tasks/tutorial_tasks.py
Celery 任务定义

C1（V2.6）：所有任务体必须是同步函数（prefork 池不支持顶层 async def）。
           内部通过 asyncio.run() 执行异步逻辑，每个 worker 进程独立事件循环。
"""
import asyncio

import structlog
from celery import Celery

from apps.api.core.config import CONFIG

logger = structlog.get_logger(__name__)

celery_app = Celery(
    "adaptive_learning",
    broker=CONFIG.rabbitmq.celery_broker_url,
    backend="rpc://",
)
celery_app.conf.update(
    task_serializer       = "json",
    result_serializer     = "json",
    accept_content        = ["json"],
    timezone              = "UTC",
    enable_utc            = True,
    task_acks_late        = True,
    worker_prefetch_multiplier = 1,
    task_routes = {
        "apps.api.tasks.tutorial_tasks.generate_skeleton":        {"queue": "tutorial"},
        "apps.api.tasks.tutorial_tasks.generate_content":         {"queue": "tutorial"},
        "apps.api.tasks.tutorial_tasks.generate_annotations":     {"queue": "tutorial"},
        "apps.api.tasks.tutorial_tasks.prebuild_placement_bank":  {"queue": "low_priority"},
        "apps.api.tasks.knowledge_tasks.run_extraction":          {"queue": "knowledge"},
    }
)


# ─────────────────────────────────────────────────────────────────
# 骨架生成任务
# ─────────────────────────────────────────────────────────────────
@celery_app.task(bind=True, max_retries=2, default_retry_delay=5)
def generate_skeleton(self, tutorial_id: str, topic_key: str, requesting_user_id: str):
    """
    C1：同步包装 + asyncio.run()。
    骨架是主题级通用资产，不依赖任何用户信息。
    生成完成后发布 skeleton_generated 事件。
    """
    try:
        asyncio.run(_generate_skeleton_async(tutorial_id, topic_key, requesting_user_id))
    except Exception as exc:
        logger.error("generate_skeleton failed", error=str(exc))
        raise self.retry(exc=exc)


async def _generate_skeleton_async(
    tutorial_id: str, topic_key: str, requesting_user_id: str
) -> None:
    from apps.api.core.db import get_independent_db
    from apps.api.modules.tutorial.tutorial_service import TutorialGenerationService
    async with get_independent_db() as session:
        svc = TutorialGenerationService(session)
        await svc.build_skeleton(tutorial_id, topic_key, requesting_user_id)


# ─────────────────────────────────────────────────────────────────
# 内容填充任务
# ─────────────────────────────────────────────────────────────────
@celery_app.task(bind=True, max_retries=2, default_retry_delay=10)
def generate_content(self, tutorial_id: str):
    """C1：同步包装。LLM 驱动，内容生成失败可独立重试，不影响骨架。"""
    try:
        asyncio.run(_generate_content_async(tutorial_id))
    except Exception as exc:
        logger.error("generate_content failed", tutorial_id=tutorial_id, error=str(exc))
        raise self.retry(exc=exc)


async def _generate_content_async(tutorial_id: str) -> None:
    from apps.api.core.db import get_independent_db
    from apps.api.modules.tutorial.tutorial_service import TutorialGenerationService
    async with get_independent_db() as session:
        svc = TutorialGenerationService(session)
        await svc.fill_content(tutorial_id)


# ─────────────────────────────────────────────────────────────────
# Annotations 生成任务（事件驱动，B3修复）
# ─────────────────────────────────────────────────────────────────
@celery_app.task(bind=True, max_retries=2, default_retry_delay=5)
def generate_annotations(self, tutorial_id: str, topic_key: str, user_id: str):
    """C1：同步包装。订阅 skeleton_generated 事件后触发，消除轮询重试竞态。"""
    try:
        asyncio.run(_generate_annotations_async(tutorial_id, topic_key, user_id))
    except Exception as exc:
        logger.error("generate_annotations failed", error=str(exc))
        raise self.retry(exc=exc)


async def _generate_annotations_async(
    tutorial_id: str, topic_key: str, user_id: str
) -> None:
    from apps.api.core.db import get_independent_db
    async with get_independent_db() as session:
        # 获取用户漏洞报告
        from apps.api.modules.learner.learner_service import GapScanService
        gap_svc = GapScanService(session)
        gap_report = await gap_svc.scan(user_id, topic_key)

        # 获取骨架章节树
        result = await session.execute(
            __import__("sqlalchemy").text(
                "SELECT chapter_tree FROM tutorial_skeletons WHERE tutorial_id = :tid"
            ),
            {"tid": tutorial_id}
        )
        row = result.fetchone()
        if not row:
            return

        weak_ids = {wp["entity_id"] for wp in gap_report.get("weak_points", [])}

        # 为每个薄弱点章节创建 annotation
        for chapter in (row.chapter_tree or []):
            for eid in chapter.get("target_entity_ids", []):
                if eid in weak_ids:
                    await session.execute(
                        __import__("sqlalchemy").text("""
                            INSERT INTO tutorial_annotations
                              (annotation_id, tutorial_id, user_id, chapter_id,
                               gap_types, priority_boost, is_weak_point)
                            VALUES
                              (:aid, :tid, :uid, :chid, :gaps::jsonb, 0.5, true)
                            ON CONFLICT (tutorial_id, user_id, chapter_id)
                            DO UPDATE SET priority_boost = 0.5, is_weak_point = true
                        """),
                        {
                            "aid":  __import__("uuid").uuid4().__str__(),
                            "tid":  tutorial_id,
                            "uid":  user_id,
                            "chid": chapter.get("chapter_id", ""),
                            "gaps": __import__("json").dumps(["mechanism"]),
                        }
                    )
        await session.commit()
        logger.info("Annotations generated", tutorial_id=tutorial_id, user_id=user_id)


# ─────────────────────────────────────────────────────────────────
# 冷启动题库预生成（低优先级离线任务）
# ─────────────────────────────────────────────────────────────────
@celery_app.task(queue="low_priority", bind=True, max_retries=1)
def prebuild_placement_bank(self, topic_key: str):
    """C1：同步包装。题库预生成，用户请求时直接读缓存，P95 < 50ms。"""
    try:
        asyncio.run(_prebuild_placement_bank_async(topic_key))
    except Exception as exc:
        logger.error("prebuild_placement_bank failed", topic_key=topic_key, error=str(exc))
        raise self.retry(exc=exc)


async def _prebuild_placement_bank_async(topic_key: str) -> None:
    from apps.api.core.db import get_independent_db
    from apps.api.core.llm_gateway import get_llm_gateway
    import uuid as _uuid
    import json as _json
    import datetime as _dt
    from sqlalchemy import text as _text

    async with get_independent_db() as session:
        result = await session.execute(
            _text("SELECT is_ready FROM placement_question_banks WHERE topic_key = :tk"),
            {"topic_key": topic_key}
        )
        row = result.fetchone()
        if row and row.is_ready:
            return  # 题库已就绪，跳过

        llm = get_llm_gateway()
        domains_result = await session.execute(
            _text("""
                SELECT DISTINCT domain_tag FROM knowledge_entities
                WHERE review_status = 'approved'
                LIMIT 6
            """)
        )
        domains = [r.domain_tag for r in domains_result.fetchall()]

        questions_by_domain: dict = {}
        for domain in domains:
            domain_questions = []
            for difficulty in ("basic", "advanced"):
                prompt = (
                    f"请为领域「{domain}」生成一道{difficulty}难度的单选题，"
                    "考查核心概念掌握情况。"
                    "以JSON格式输出：{{\"stem\": \"题目\", \"options\": [\"A.\",\"B.\",\"C.\",\"D.\"], \"answer\": \"A\"}}"
                )
                try:
                    resp = await llm.generate(prompt, model_route="quiz_generation")
                    import re
                    clean = re.sub(r"^```json\s*|\s*```$", "", resp.strip())
                    q_data = _json.loads(clean)
                    domain_questions.append({
                        "question_id": str(_uuid.uuid4()),
                        "domain":      domain,
                        "difficulty":  difficulty,
                        "stem":        q_data.get("stem", f"请选择关于{domain}的正确描述"),
                        "options":     q_data.get("options", ["A", "B", "C", "D"]),
                        "answer":      q_data.get("answer", "A"),
                    })
                except Exception as e:
                    logger.warning("Quiz gen failed", domain=domain, difficulty=difficulty, error=str(e))
                    domain_questions.append({
                        "question_id": str(_uuid.uuid4()),
                        "domain":      domain,
                        "difficulty":  difficulty,
                        "stem":        f"您对「{domain}」领域的了解程度是？",
                        "options":     ["A. 熟练", "B. 了解", "C. 不熟悉", "D. 完全不了解"],
                        "answer":      "A",
                    })
            questions_by_domain[domain] = domain_questions

        bank_id = str(_uuid.uuid4())
        await session.execute(
            _text("""
                INSERT INTO placement_question_banks
                  (bank_id, topic_key, questions_by_domain, is_ready, built_at, expires_at)
                VALUES
                  (:bid, :tk, :qbd::jsonb, true, NOW(), NOW() + INTERVAL '7 days')
                ON CONFLICT (topic_key)
                DO UPDATE SET
                  questions_by_domain = EXCLUDED.questions_by_domain,
                  is_ready = true, built_at = NOW(),
                  expires_at = NOW() + INTERVAL '7 days'
            """),
            {"bid": bank_id, "tk": topic_key,
             "qbd": _json.dumps(questions_by_domain, ensure_ascii=False)}
        )
        await session.commit()
        logger.info("Placement bank built", topic_key=topic_key, domains=len(domains))
